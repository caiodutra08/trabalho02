// Atributos:

// Para a classe Gasto: tipo (String), data (Date), valor (double), formaPagamento (String)
// Para a classe Ganho: tipo (String), data (Date), valor (double)

// Métodos:
// Para a classe Gasto: construtor, getters e setters
// Para a classe Ganho: construtor, getters e setters

// Classes:

// Gasto
// Ganho

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);
    public static Gasto[] gastos = new Gasto[100];
    public static Ganho[] ganhos = new Ganho[100];
    public static int qtdGastos = 0;
    public static int qtdGanhos = 0;
    private static final String[] OPCOES_GASTO = {"1", "2", "3", "4", "X", "99"};
    private static final String[] OPCOES_GANHO = {"1", "2", "3", "X", "99"};
    private static final String[] FORMAS_PAGAMENTO = {"1", "2", "3", "4"};

    public static void main(String[] args) {
        int opcao;
        do {
            opcao = exibirMenu();
            switch (opcao) {
                case 1 -> adicionarGasto();
                case 2 -> adicionarGanho();
                case 3 -> relatorioGastos();
                case 4 -> relatorioGanhos();
                case 5 -> relatorioMensal();
                case 6 -> System.out.println("Saindo...");
                default -> System.out.println("Opção inválida");
            }
        } while (opcao != 6);
    }

    public static int exibirMenu() {
        System.out.println("\nGestão Financeira\n-----------------------");
        System.out.println("1 - Adicionar Gasto");
        System.out.println("2 - Adicionar Ganho");
        System.out.println("3 - Relatório de Gastos");
        System.out.println("4 - Relatório de Ganhos");
        System.out.println("5 - Relatório Mensal");
        System.out.println("6 - Sair");
        System.out.print("\nSelecione uma opção: ");
        return sc.nextInt();
    }

    public static void adicionarGasto() {
        String tipo = obterTipoDeGasto();
        if (tipo == null) {
            System.out.println("Opção inválida");
            return;
        }

        Date data = obterData("gasto");
        if (data == null) {
            System.out.println("Data inválida");
            return;
        }

        double valor = obterValor("gasto");
        if (valor == -1) {
            System.out.println("Valor inválido");
            return;
        }

        String formaPagamento = obterFormaDePagamento();
        if (formaPagamento == null) {
            System.out.println("Opção inválida");
            return;
        }

        Gasto gasto = new Gasto(tipo, data, valor, formaPagamento);
        gastos[qtdGastos] = gasto;
        qtdGastos++;
        System.out.println("Gasto adicionado com sucesso");
    }

    public static void adicionarGanho() {
        double valor = obterValor("ganho");
        if (valor == -1) {
            System.out.println("Valor inválido");
            return;
        }

        String tipo = obterTipoDeGanho();
        if (tipo == null) {
            System.out.println("Opção inválida");
            return;
        }

        Date data = obterData("ganho");
        if (data == null) {
            System.out.println("Data inválida");
            return;
        }

        Ganho ganho = new Ganho(tipo, data, valor);
        ganhos[qtdGanhos] = ganho;
        qtdGanhos++;
        System.out.println("Ganho cadastrado com sucesso!");
    }

    private static String obterTipoDeGasto() {
        System.out.println("\nSelecione o tipo de gasto:");
        System.out.println("1 - Alimentação");
        System.out.println("2 - Transporte");
        System.out.println("3 - Moradia");
        System.out.println("4 - Lazer");
        System.out.println("X - Outros");
        System.out.println("99 - Cancelar");
        System.out.print("Opção: ");
        String opcao = sc.next();

        if (opcao.equals("99")) {
            return null;
        }

        if (opcao.equals("X")) {
            System.out.print("Informe o tipo de gasto: ");
            sc.nextLine();
            return sc.nextLine();
        }

        if (!Arrays.asList(OPCOES_GASTO).contains(opcao)) return null;

        return switch (opcao) {
            case "1" -> "Alimentação";
            case "2" -> "Transporte";
            case "3" -> "Moradia";
            case "4" -> "Lazer";
            default -> null;
        };
    }

    private static String obterTipoDeGanho() {
        System.out.print("\nSelecione o tipo de ganho: ");
        System.out.println("1 - Salário");
        System.out.println("2 - Freelancer");
        System.out.println("3 - Rendimento");
        System.out.println("X - Outros");
        System.out.print("Opção: ");
        String opcao = sc.next();

        if (opcao.equals("X")) {
            System.out.print("Informe o tipo de ganho: ");
            sc.nextLine();
            return sc.nextLine();
        }

        if (!Arrays.asList(OPCOES_GANHO).contains(opcao)) return null;

        return switch (opcao) {
            case "1" -> "Salário";
            case "2" -> "Freelancer";
            case "3" -> "Rendimento";
            default -> null;
        };
    }

    private static Date obterData(String module) {
        System.out.print("Informe a data do " + module + " (dd/mm/aaaa): ");
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

        try {
            return format.parse(sc.next());
        } catch (ParseException e) {
            return null;
        }
    }

    private static double obterValor(String module) {
        System.out.print("Informe o valor do " + module + ": ");
        DecimalFormat df = new DecimalFormat("#,##0.00");

        try {
            return df.parse(sc.next()).doubleValue();
        } catch (ParseException e) {
            return -1;
        }
    }

    private static String obterFormaDePagamento() {
        System.out.println("\nSelecione a forma de pagamento:");
        System.out.println("1 - Dinheiro");
        System.out.println("2 - Cartão de Crédito");
        System.out.println("3 - Cartão de Débito");
        System.out.print("Opção: ");
        String opcao = sc.next();

        if (!Arrays.asList(FORMAS_PAGAMENTO).contains(opcao)) return null;

        return switch (opcao) {
            case "1" -> "Pix";
            case "2" -> "Cartão de Crédito";
            case "3" -> "Cartão de Débito";
            case "4" -> "Boleto";
            default -> null;
        };
    }

    public static void relatorioGastos() {
        double totalGasto = 0.0;
        System.out.println("=== Relatório de Gastos ===");
        for (Gasto gasto : gastos) {
            if (gasto != null) {
                System.out.println("Tipo: " + gasto.getTipo());
                System.out.println("Valor: R$ " + gasto.getValor());
                System.out.println("Data: " + gasto.getData());
                System.out.println("Forma de Pagamento: " + gasto.getFormaPagamento());
                System.out.println("--------------------------");
                totalGasto += gasto.getValor();
            }
        }

        System.out.println("Total de Gastos: R$ " + totalGasto);
    }

    public static void relatorioGanhos() {
        double totalGanho = 0.0;

        System.out.println("=== Relatório de Ganhos ===");
        for (Ganho ganho : ganhos) {
            if (ganho != null) {
                System.out.println("Tipo: " + ganho.getTipo());
                System.out.println("Valor: R$" + ganho.getValor());
                System.out.println("Data: " + ganho.getData());
                System.out.println("--------------------------");
                totalGanho += ganho.getValor();
            }
        }

        System.out.println("Total de Ganhos: R$ " + totalGanho);
    }

    public static void relatorioMensal() {
        System.out.println("---- Relatório Mensal ----");

        System.out.println("Informe o mês desejado (1-12): ");
        int mes = sc.nextInt();

       System.out.println("Informe o ano desejado: ");
        int ano = sc.nextInt();

        double totalGasto = 0.0;
        double totalGanho = 0.0;

        for (Gasto gasto : gastos) {
            if (gasto != null) {
                totalGasto = getTotal(mes, ano, totalGasto, gasto.getData(), gasto.getValor());
            }
        }

        for (Ganho ganho : ganhos) {
            if (ganho != null) {
                totalGanho = getTotal(mes, ano, totalGanho, ganho.getData(), ganho.getValor());
            }
        }

        System.out.println("Total de Gastos: R$ " + totalGasto);
        System.out.println("Total de Ganhos: R$ " + totalGanho);
        System.out.println("Saldo: R$ " + (totalGanho - totalGasto));
    }

    private static double getTotal(int mes, int ano, double total, Date data, double valor) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(data);
        int mesGasto = calendar.get(Calendar.MONTH) + 1;
        int anoGasto = calendar.get(Calendar.YEAR);

        if (mesGasto == mes && anoGasto == ano) {
            total += valor;
        }
        return total;
    }
}